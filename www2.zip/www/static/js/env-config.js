window._env_ = {
  AMPLITUDE_API_KEY: "a205ed9b06a7baf5a594bdd30293aa80",
  SENTRY_DSN: "https://f595bc90ce3646c4a9d76a8d3b84b403@sentry.io/2071895",
  IS_ONPREM: "false",
  USE_STATIC_PREVIEW: "false",
  PREVIEW_DOMAIN: "csb.app",
  ROWS_API_KEY: """",
}
