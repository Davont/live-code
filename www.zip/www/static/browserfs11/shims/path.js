module.exports = BrowserFS.BFSRequire('path');
