/**
 * @hidden
 */
declare const toExport: any;
export default toExport;
