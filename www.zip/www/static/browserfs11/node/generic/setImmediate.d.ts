/**
 * @hidden
 */
declare let bfsSetImmediate: (cb: Function, ...args: any[]) => any;
export default bfsSetImmediate;
