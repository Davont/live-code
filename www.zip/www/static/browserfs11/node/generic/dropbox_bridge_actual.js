"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dropbox = void 0;
var global_1 = require("../core/global");
// If Dropbox isn't on the webpage, then set this to null.
exports.Dropbox = global_1.default.Dropbox ? global_1.default.Dropbox.Dropbox : undefined;
//# sourceMappingURL=dropbox_bridge_actual.js.map